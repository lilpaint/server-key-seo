var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var exphbs  = require('express-handlebars');
var mysql = require('mysql');
var session = require('express-session');
var FormData = require('form-data');
var axios = require('axios');
const { Cookie } = require('express-session');
var url = require('url');
var https = require('https');
var queryString = require('querystring');
var fs = require('fs');
const HttpsProxyAgent = require('https-proxy-agent');
const { Agent } = require('http');
var request = require('request');

app.engine('hbs', exphbs({
    extname: '.hbs'
  }));
app.set('view engine', 'hbs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.set('views', './views');
app.get('/', function (req, res) {
    return res.render('home')
});
var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Fakepw1-',
    database: 'group'
});
db.connect();


app.get('/', function(request, response) {
	response.sendFile(path.join(__dirname + 'views/home.hbs'));
});

app.get('/index1', function(request, response) {

	response.sendFile(path.join(__dirname + 'views/index.hbs'));
});



app.post('/check', async function(req, res, next) {
    let code = req.body.code;
    let sql = 'SELECT * FROM account WHERE code = ?';
    if(!code){
        res.send("error")
    }
    else{
        db.query(sql, [code] , (err, rows) => {   
            if (rows.length <= 0 ) { res.send("Key Expired")}
            else {
                res.send({ code: rows[0].code, expire: rows[0].expire, keyproxy: rows[0].keyproxy });
            }
        });   
    }
   });


app.post('/addkey', async function(req, res, next) {
    let code = req.body.code
    let expire = req.body.expire
    let note = req.body.note
    let sql = 'INSERT INTO `account` (code, expire, note)  VALUES (?,?,?);';
    if(!code || !expire){
        res.send("error")
    }
    else{
        db.query(sql, [code, expire, note] , (err, ok) => {   
            if(err){return err}
            if(ok){
                res.redirect('/index')
            }
        });   
    }
   });

app.get('/index', async function(req, res, next) {
    let sql = 'select * from account';
    db.query(sql, (err, ok) => {   
        if(err){return err}
        if(ok){
            res.render('index', {ok:ok})
        }
    });   
});

app.post('/delete', async function(req, res, next) {
    let code = req.body.code
    let sql = 'DELETE FROM account WHERE code = ?';
    if(!code){
        res.send("error")
    }
    else
    {
        db.query(sql,[code], (err, ok) => {   
            if(err){return err}
            if(ok){
                res.redirect('/index')
            }
        });   
    }
});

app.get('/date', async function(req, res, next) {
    let sql = 'UPDATE account SET expire = expire - 1';
    db.query(sql, (err, ok) => {   
        if(err){return err}
        if(ok){
            
        }
    });   
});

    
app.listen(3000, function () {
    console.log('Node app is running on port 3000');
});



module.exports = app;